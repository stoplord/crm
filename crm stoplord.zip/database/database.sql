SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+05:30"; -- Asia/Kolkata

CREATE TABLE `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `role` ENUM('super_admin', 'admin') NOT NULL,
  `name` VARCHAR(100) NOT NULL,
  `email` VARCHAR(100) NOT NULL UNIQUE,
  `mobile` VARCHAR(15) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `pin_hash` VARCHAR(255) NULL COMMENT 'Only for Super Admin 2FA',
  `status` ENUM('active', 'inactive') DEFAULT 'active',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `admin_profiles` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `alternative_number` VARCHAR(15) NULL,
  `dob` DATE NULL,
  `address` TEXT NULL,
  `city` VARCHAR(50) NULL,
  `state` VARCHAR(50) NULL,
  `pin_code` VARCHAR(10) NULL,
  `profile_photo` VARCHAR(255) NULL,
  `aadhaar_number` VARCHAR(20) NULL,
  `aadhaar_photo` VARCHAR(255) NULL,
  `pan_number` VARCHAR(20) NULL,
  `pan_photo` VARCHAR(255) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `clients` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `client_code` VARCHAR(20) NOT NULL UNIQUE,
  `name` VARCHAR(100) NOT NULL,
  `phone` VARCHAR(15) NOT NULL,
  `whatsapp` VARCHAR(15) NULL,
  `email` VARCHAR(100) NULL,
  `address` TEXT NULL,
  `city` VARCHAR(50) NULL,
  `state` VARCHAR(50) NULL,
  `pin_code` VARCHAR(10) NULL,
  `requirement` TEXT NULL,
  `temperature` ENUM('HOT', 'COLD') DEFAULT 'COLD',
  `status` VARCHAR(50) DEFAULT 'New',
  `deal_status` ENUM('Open', 'In Progress', 'Converted', 'Rejected', 'On Hold') DEFAULT 'Open',
  `quotation_amount` DECIMAL(10,2) NULL,
  `final_price` DECIMAL(10,2) NULL,
  `rejection_reason` TEXT NULL,
  `assigned_admin_id` INT NULL,
  `created_by` INT NOT NULL,
  `updated_by` INT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at` TIMESTAMP NULL DEFAULT NULL,
  FOREIGN KEY (`assigned_admin_id`) REFERENCES `users`(`id`),
  FOREIGN KEY (`created_by`) REFERENCES `users`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `client_activities` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `client_id` INT NOT NULL,
  `admin_id` INT NOT NULL,
  `activity_type` VARCHAR(50) NOT NULL,
  `activity_date` DATE NOT NULL,
  `activity_time` TIME NOT NULL,
  `notes` TEXT NULL,
  `next_followup_date` DATETIME NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`client_id`) REFERENCES `clients`(`id`),
  FOREIGN KEY (`admin_id`) REFERENCES `users`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `meetings` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `client_id` INT NOT NULL,
  `admin_id` INT NOT NULL,
  `meeting_date` DATE NOT NULL,
  `meeting_time` TIME NOT NULL,
  `meeting_type` VARCHAR(50) NOT NULL,
  `location` VARCHAR(255) NULL,
  `meeting_link` VARCHAR(255) NULL,
  `notes` TEXT NULL,
  `status` ENUM('Scheduled', 'Completed', 'Cancelled', 'Rescheduled') DEFAULT 'Scheduled',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (`client_id`) REFERENCES `clients`(`id`),
  FOREIGN KEY (`admin_id`) REFERENCES `users`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `work_sessions` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `admin_id` INT NOT NULL,
  `login_time` DATETIME NOT NULL,
  `last_activity` DATETIME NOT NULL,
  `logout_time` DATETIME NULL,
  `duration_seconds` INT DEFAULT 0,
  `logout_reason` VARCHAR(50) NULL,
  `ip_address` VARCHAR(45) NULL,
  `user_agent` TEXT NULL,
  `session_date` DATE NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`admin_id`) REFERENCES `users`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `daily_work_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `admin_id` INT NOT NULL,
  `work_date` DATE NOT NULL,
  `total_seconds` INT DEFAULT 0,
  `target_seconds` INT DEFAULT 21600, -- 6 hours default
  `status` VARCHAR(20) DEFAULT 'Low',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `unique_admin_date` (`admin_id`, `work_date`),
  FOREIGN KEY (`admin_id`) REFERENCES `users`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `audit_logs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `user_id` INT NOT NULL,
  `role` VARCHAR(20) NOT NULL,
  `action` VARCHAR(100) NOT NULL,
  `target_type` VARCHAR(50) NOT NULL,
  `target_id` INT NULL,
  `description` TEXT NOT NULL,
  `ip_address` VARCHAR(45) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE `settings` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `setting_key` VARCHAR(50) NOT NULL UNIQUE,
  `setting_value` TEXT NOT NULL,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Seed Initial Super Admin (Password: Admin@123, PIN: 1234)
-- Note: Replace PIN and Password hashes in production using password_hash()
INSERT INTO `users` (`role`, `name`, `email`, `mobile`, `password`, `pin_hash`) 
VALUES ('super_admin', 'System Admin', 'admin@crm.local', '9999999999', 
'$2y$10$wO3t0Z.8i.l9nQk/...', '$2y$10$xyz...'); 

-- Add Indexes for Performance
CREATE INDEX idx_client_code ON clients(client_code);
CREATE INDEX idx_client_status ON clients(status, deal_status);
CREATE INDEX idx_temperature ON clients(temperature);
CREATE INDEX idx_work_date ON daily_work_logs(work_date);